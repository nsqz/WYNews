//
//  NSString+Time.h
//  WYnewsss
//
//  Created by lanou on 16/4/20.
//  Copyright © 2016年 lanou. All rights reserved.
//将时间字符串转换为常用的时间字符串

#import <Foundation/Foundation.h>

@interface NSString (Time)

+ (NSString *)dateStringWithString:(NSString *)string :( NSString *)dateFormater;



@end
