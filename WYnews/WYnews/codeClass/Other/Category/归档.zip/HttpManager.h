//
//  HttpManager.h
//  WYnewsss
//
//  Created by lanou on 16/4/25.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface HttpManager : AFHTTPSessionManager
+ (instancetype)manager;

@end
